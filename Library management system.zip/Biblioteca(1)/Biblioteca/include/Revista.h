#ifndef REVISTA_H
#define REVISTA_H
#include <iostream>
#include <string>
#include "Item.h"
using namespace std;

class Revista : public Item
{

    public:
        Revista();
        virtual ~Revista();

    protected:

    private:
};

#endif // REVISTA_H
