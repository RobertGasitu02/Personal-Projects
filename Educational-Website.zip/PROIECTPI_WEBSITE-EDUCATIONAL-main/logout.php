<!DOCTYPE html>
<html>


<head>
<meta charset="UTF-8">
<title>Șiruri de caractere</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>

<div class='container'>

   <header>
	<img src="logo.png" alt="robi's logo">

	   <nav>
	   	 <ul>
	   	 	<li><a href="index.php">INTRODUCERE</a></li>
	   	 	<li><a href="functii.php">FUNCȚII</a></li>
	   	 	<li><a href="probleme_rezolvate.php">PROBLEME REZOLVATE</a></li>
	   	 	<li><a href="probleme_propuse.[h[]]">PROBLEME PROPUSE</a></li>
	   	 	<li><a href="teste.php">TESTE</a></li>
	   	 	<li><a href="contact.php">CONTACT</a></li>
	   	 	<li><a href="signup.php">LOGIN</a></li>
	   	 </ul>
           
		
	  </nav>

   </header>
</div>

<section>
	<form action="log_out.php" method="POST">
  		<input type="submit" value="Deconectare" class="submit" name="LOGOUT">

</form>
 		



</section>

<br>
	

</body>


</html>