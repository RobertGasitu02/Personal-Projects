import java.util.ArrayList;

public class Dictionary {
    private static final int INITIAL_CAPACITY = 16;
    private ArrayList[] values;
    private int size;

    public Dictionary() {
        values = new ArrayList[INITIAL_CAPACITY];
        size = 0;
    }

    private int hash(double key) {
        return (int)(Double.doubleToLongBits(key) % values.length);
    }

    public void add(double key) {
        int index = hash(key);
        if (values[index] == null) {
            values[index] = new ArrayList<>();
            values[index].add(1);
            size++;
        }else{
            int count = (int) values[index].get(0);
            values[index].set(0,count+1);
        }
    }
    public int getSum(double key) {
        ArrayList<Integer> values = get(key);
        if (values == null) {
            return 0;
        }
        return values.get(0);
    }

    public ArrayList<Integer> get(double key) {
        int index = hash(key);
        return values[index] == null ? null : values[index];
    }
}
