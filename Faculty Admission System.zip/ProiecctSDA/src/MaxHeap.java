import java.util.ArrayList;

public class MaxHeap {
    private ArrayList<Double> heap;

    public MaxHeap() {
        heap = new ArrayList<Double>();
    }

    // Functia de adaugare
    public void add(double value) {
        heap.add(value);
        int currentIndex = heap.size() - 1;
        int parentIndex = (currentIndex - 1) / 2;
        // While we're not at the root and the current element is greater than its parent
        while (currentIndex > 0 && heap.get(currentIndex) > heap.get(parentIndex)) {
            // Swap the current element with its parent
            double temp = heap.get(currentIndex);
            heap.set(currentIndex, heap.get(parentIndex));
            heap.set(parentIndex, temp);
            currentIndex = parentIndex;
            parentIndex = (currentIndex - 1) / 2;
        }
    }

    // Scoate si da return la element
    public double remove() {
        if (heap.size() == 0) {
            throw new IllegalStateException("Heap is empty");
        } else if (heap.size() == 1) {
            return heap.remove(0);
        }
        double max = heap.get(0);
        heap.set(0, heap.remove(heap.size() - 1));
        int currentIndex = 0;
        int leftChildIndex = (currentIndex * 2) + 1;
        int rightChildIndex = (currentIndex * 2) + 2;
        while (leftChildIndex < heap.size() && rightChildIndex < heap.size()) {
            int maxChildIndex = heap.get(leftChildIndex) > heap.get(rightChildIndex) ? leftChildIndex : rightChildIndex;
            if (heap.get(currentIndex) < heap.get(maxChildIndex)) {
                double temp = heap.get(currentIndex);
                heap.set(currentIndex, heap.get(maxChildIndex));
                heap.set(maxChildIndex, temp);
                currentIndex = maxChildIndex;
                leftChildIndex = (currentIndex * 2) + 1;
                rightChildIndex = (currentIndex * 2) + 2;
            } else {
                break;
            }
        }
        return max;
    }

    // Return the maximum element from the heap without removing it
    public double peek() {
        if (heap.size() == 0) {
            throw new IllegalStateException("Heap is empty");
        }
        return heap.get(0);
    }

    public int size() {
        return heap.size();
    }
}