import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void insertAplicants(ArrayList<Aplicant> lista,double avg){
        for(Aplicant i : lista){
            if(i.getMedie()>=avg)
                i.writeToFile("StudentiAdmisi.ser");
        }
    }




    public static void main(String[] args) {

        //Adaugare date relevante pentru testarea aplicatiei
        ArrayList<Aplicant> lista = new ArrayList<>();
        lista.add(new Aplicant("Ionescu","Andrei",18,8.83));
        lista.add(new Aplicant("Gasitu","Robert",20,9.15));
        lista.add(new Aplicant("Marinescu","Raul",22,9.55));
        lista.add(new Aplicant("Moldovan","Razvan",19,7.28));
        lista.add(new Aplicant("Talmaciu","Eduard",26,5.12));
        lista.add(new Aplicant("Goina","Roxana",35,8.76));
        lista.add(new Aplicant("Marinel","Claudiu",19,7.28));
        lista.add(new Aplicant("Georgescu","Diana",18,9.55));
        lista.add(new Aplicant("Pana","Ioana",18,8.83));
        lista.add(new Aplicant("Panait","Camelia",22,8.83));
        lista.add(new Aplicant("Anghelescu","Alexandru",19,8.15));
        lista.add(new Aplicant("Popescu","Eduard",18,5.12));
        lista.add(new Aplicant("Ion","Maria",25,8.76));
        lista.add(new Aplicant("Marian","Denis",19,7.28));
        lista.add(new Aplicant("Martin","Irina",19,9.88));
        lista.add(new Aplicant("Reja","Mario",32,8.87));
        lista.add(new Aplicant("Secrieru","Stefan",35,8.83));
        lista.add(new Aplicant("Marian","Denis",19,7.28));
        lista.add(new Aplicant("Boboescu","Andreea",20,9.33));
        lista.add(new Aplicant("Forti","Florin",30,7.28));
        lista.add(new Aplicant("Dobrea","Ovidiu",22,8.72));
        lista.add(new Aplicant("Rares","Denis",18,7.76));
        lista.add(new Aplicant("Martin","Irina",19,9.88));
        lista.add(new Aplicant("Dumitescu","Ion",22,7.76));
        lista.add(new Aplicant("Ion","Ion",19,9.93));


        double last=0;
        MaxHeap heap = new MaxHeap();
        Dictionary dict = new Dictionary();
        //Preluarea datelor necesare din lista de Aplicanti
        for(Aplicant i : lista){
            heap.add(i.getMedie());
            dict.add(i.getMedie());
        }
        System.out.println("#SISTEM ADMITERE STUDENTI PE BAZA MEDIEI#");
        boolean condition = true;
        Scanner scanner = new Scanner(System.in);
        System.out.print("INTRODU  NUMARUL DE STUDENTI CE DORESTI SA FIE ADMISI: ");
        int userInput = scanner.nextInt();
        int cp = userInput;

        while(condition){
            double avg = heap.peek();
            //  System.out.println(avg);
            // System.out.println(dict.get(avg));
            //System.out.println(dict.getSum(avg));
            int sum= dict.getSum(avg);

            if(sum <= userInput){
                System.out.println("Media: "+avg+" numar de aplicanti: "+sum);
                userInput = userInput - sum;
                last = avg;
            }
            else {
                condition = false;
                int left = cp - userInput;
                System.out.println("#######################################");
                System.out.println("Procesul de selectia a fost finalizat");
                System.out.println("Au fost ocupate "+ left + " locuri din " + cp);
                System.out.println("Ultima medie de admitere sub linie este : " + avg);

                System.out.println("#######################################");
            }
            double lastAvg = heap.peek();
            heap.remove();
            while(avg==heap.peek()){
                heap.remove();
            }

        }
        //System.out.println(last);
        insertAplicants(lista,last);
    }

    }

