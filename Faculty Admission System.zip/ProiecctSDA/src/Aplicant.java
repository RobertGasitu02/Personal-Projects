import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Aplicant implements Serializable {
    private String nume;
    private String prenume;
    private int varsta;
    private double medie;

    public Aplicant(String nume, String prenume, int varsta, double medie) {
        this.nume = nume;
        this.prenume = prenume;
        this.varsta = varsta;
        this.medie = medie;
    }

    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public int getVarsta() {
        return varsta;
    }

    public double getMedie() {
        return medie;
    }

    public void writeToFile(String fileName) {
        try {
            FileOutputStream fileOut = new FileOutputStream(fileName);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(this);
            out.close();
            fileOut.close();
            System.out.printf("Aplicantii admisi au fost salvati in %s", fileName);
        } catch (IOException i) {
            i.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "Aplicant{" +
                "nume='" + nume + '\'' +
                ", prenume='" + prenume + '\'' +
                ", varsta='" + varsta + '\'' +
                ", medie=" + medie +
                '}';
    }
}
