package com.example.demo4;

public class VizAngajati {
    private String name;
    private String dept;

    public VizAngajati(String name, String dept) {
        this.name = name;
        this.dept = dept;
    }
    public VizAngajati(){

    }

    public void setName(String name) {
        this.name = name;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public String getName() {
        return name;
    }

    public String getDept() {
        return dept;
    }

    @Override
    public String toString() {
        return "VizAngajati{" +
                "name='" + name + '\'' +
                ", dept='" + dept + '\'' +
                '}';
    }
}
