package com.example.demo4;
import java.io.File;
import java.sql.*;
import com.example.demo4.Personal;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import java.io.IOException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;

public class RegisterFormController
{
    @FXML
    private TextField rName,rPrenume,rUsername,rVarsta,rEmail,rParola;

    @FXML
    private Button registerButton;

    @FXML
    private Button goBackButton;

    @FXML
    private Button uploadButton;

    @FXML
    private Stage stage;
    @FXML
    private Scene scene;

    /**
     * Aceasta metoda deschide dialog-ul pentru selectarea CV-ului
     * se extrag datele acestuia din el si se auto-completeaza campurile
     * din formularul de creare cont.
     * Se trimite catre utilizator un mail impreuna cu username-ul si parola acestuia
     * Parola se genereaza automat.
     * @param event
     */
    @FXML
    protected void handleUploadAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );

        File selectedFile = fileChooser.showOpenDialog(uploadButton.getScene().getWindow());

        if (selectedFile != null) {
            // code to handle the selected file goes here
            try {
                PDDocument document = PDDocument.load(selectedFile);
                PDFTextStripper pdfText = new PDFTextStripper();

                String pdftextdata = pdfText.getText(document);
                //System.out.println(pdftextdata);
                //String input = "Nume: John  Prenume: Doe   Username: johndoe Varsta: 30 Email: john.doe@example.com";
                List<String> skipWords = Arrays.asList("Nume:", "Prenume:", "Username:", "Varsta:","Email:");
                int i = 0;
                String[] words = pdftextdata.split("\\s+");
                List<String> result = new ArrayList<>();
                for (String word : words) {
                    if (!skipWords.contains(word)) {
                        result.add(word);
                        if(i==0)
                        {
                            rName.setText(word);
                            i=1;
                        }else if(i==1){
                            rPrenume.setText(word);
                            i=2;
                        }
                        else if(i==2){
                            rUsername.setText(word);
                            i=3;
                        }
                        else if(i==3){
                            rVarsta.setText(word);
                            i=4;
                        }
                        else if(i==4){
                            rEmail.setText(word);
                            i=5;
                        }
                       // rName.setText(word);
                       // rPrenume.setText(word);
                        //rUsername.setText(word);
                        //rVarsta.setText(word);
                    }
                }

                System.out.println(result);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


    /*
         Metoda de inserare utilizator in baza de date din formularul de creare cont
     */

    /**
     * Aceasta metoda se foloseste pentru a insera user-ul nou in tabela users
     * @param u este folosit pentru a fi transmis user-ul nou creat.
     */
    private void connectToDatabase(Personal u) {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            PreparedStatement ps = con.prepareStatement("insert into users(Nume,Prenume,Username,Parola,varsta,email) values(?,?,?,?,?,?)");
            ps.setString(1, u.getNume());
            ps.setString(2, u.getPrenume());
            ps.setString(3, u.getUsername());
            ps.setString(4, u.getParola());
            ps.setInt(5, u.getVarsta());
            ps.setString(6, u.getEmail());
            ps.executeUpdate();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }




     // Actiune buton de register cu privire la crearea utilizatorului cu datele preluate
    // se apeleaza functia connectToDatabase() si se face inserarea

    /**
     * Metoda informeaza ca procesul de crearea cont a fost realizata cu succes prin intermediul
     * unor alert-uri sugestive care sintetizeaza procesul.
     * @param event
     * @throws IOException
     */
    public void registerButtonOnAction(ActionEvent event) throws IOException {
        String pass = GeneratePassword();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Cont creat cu succes!");
        alert.setHeaderText("Email-ul a fost trimis catre "+rName.getText()+ " !");
        alert.setContentText("Operatiunea s-a sfarsit, apasa pe OK !");
        if(alert.showAndWait().get() == ButtonType.OK){
            Personal UtilizatorNou = new Personal(rName.getText(),rPrenume.getText(),rUsername.getText(),Integer.parseInt(rVarsta.getText()),rEmail.getText(),pass);
            System.out.println(UtilizatorNou);
            connectToDatabase(UtilizatorNou);
            String uname = rName.getText();
            String message = "Salut, pentru a te loga foloseste username-ul "+rUsername.getText()+" si parola " + pass;
            String gmail = rEmail.getText();
            new SendEmail( uname,message, gmail);

            Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
            stage = (Stage)((Node)event.getSource()).getScene().getWindow();
            scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }

    }

    /**
     * Aceasta metoda genereaza automat parola
     * Extrage random 8 caractere din sirul AB
     * @return returneaza parola.
     */
    public String GeneratePassword(){

        String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        Random rnd = new Random();
        StringBuilder sb = new StringBuilder(8);
        for (int i = 0; i < 8; i++) {
            sb.append(AB.charAt(rnd.nextInt(AB.length())));
        }
        return sb.toString();
    }

    /**
     * Metoda ne intoarce pe MainPage.
     * @param event
     * @throws IOException
     */
    public void BackButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Buton folosit pentru deschiderea dialog-ului de selectare a CV-ului.
     * @param event
     * @throws IOException
     */
    public void AutoButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("FileChooser.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }



}
