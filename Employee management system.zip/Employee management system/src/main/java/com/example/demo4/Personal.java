package com.example.demo4;

public class Personal {
    private int id;
    private String nume;
    private String prenume;
    private String username;
    private int varsta;
    private String email;

    private String parola;


    public Personal(String nume, String prenume, String username, int varsta, String email, String parola) {
        this.nume = nume;
        this.prenume = prenume;
        this.username = username;
        this.varsta = varsta;
        this.email = email;
        this.parola = parola;
    }
    public Personal(int id ,String nume, String prenume, String username, int varsta, String email, String parola) {
        this.id = id;
        this.nume = nume;
        this.prenume = prenume;
        this.username = username;
        this.varsta = varsta;
        this.email = email;
        this.parola = parola;
    }
    public Personal(){

    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public String getUsername() {
        return username;
    }

    public int getVarsta() {
        return varsta;
    }

    public String getEmail() {
        return email;
    }

    public String getParola() {
        return parola;
    }

    @Override
    public String toString() {
        return "Personal{" +
                "nume='" + nume + '\'' +
                ", prenume='" + prenume + '\'' +
                ", username='" + username + '\'' +
                ", varsta=" + varsta +
                ", email='" + email + '\'' +
                '}';
    }
}
