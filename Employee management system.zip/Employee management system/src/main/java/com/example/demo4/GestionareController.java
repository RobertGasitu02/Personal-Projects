package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class GestionareController {
    
    @FXML
    private Button vizAngajati;

    @FXML
    private Button vizDept;

    @FXML
    private Button backButton;

    /**
     * Metoda pentru butonul de redirectionare catre AdminMain
     * @param event
     * @throws IOException
     */
    public void BackButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Metoda pentru butonul de redirectionare catre VizualizareAngajati
     * @param event
     * @throws IOException
     */
    public void vizAngajatiButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("VizAngajati.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Metoda pentru butonul de redirectionare catre VizualizareDepartamente
     * @param event
     * @throws IOException
     */
    public void vizDeptButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("VizDepartamente.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }
}
