package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.stage.FileChooser;

import java.io.File;

public class FileChooserController {
    @FXML
    private Button uploadButton;

    /**
     * Aceasta metoda deschide un dialog pentru a putea selecta CV-ul persoanei
     * @param event
     */
    @FXML
    protected void handleUploadAction(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PDF Files", "*.pdf")
        );

        File selectedFile = fileChooser.showOpenDialog(uploadButton.getScene().getWindow());

        if (selectedFile != null) {
            // code to handle the selected file goes here

        }
    }
}
