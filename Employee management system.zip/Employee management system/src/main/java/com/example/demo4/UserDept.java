package com.example.demo4;

public class UserDept {
    private int idAng;
    private int idDept;

    public UserDept(int idAng, int idDept) {
        this.idAng = idAng;
        this.idDept = idDept;
    }

    public UserDept(){

    }

    public void setIdAng(int idAng) {
        this.idAng = idAng;
    }

    public void setIdDept(int idDept) {
        this.idDept = idDept;
    }

    public int getIdAng() {
        return idAng;
    }

    public int getIdDept() {
        return idDept;
    }

    @Override
    public String toString() {
        return "UserDept{" +
                "idAng=" + idAng +
                ", idDept=" + idDept +
                '}';
    }
}
