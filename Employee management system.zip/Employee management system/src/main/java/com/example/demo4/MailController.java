package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

public class MailController implements Initializable {
    @FXML
    private Button trimiteButton;

    @FXML
    private Button backButton;
    @FXML
    private TextField textMessage;

    @FXML
    private ChoiceBox<String> choisePerson;

    List<Personal> listaPersonal = new ArrayList<>();
    List<com.example.demo4.UserDept> listaUserDept = new ArrayList<>();
    List<com.example.demo4.VizAngajati> listaVizAngajati = new ArrayList<>();
    List<com.example.demo4.Department> departments = new ArrayList<>();


    void databaseUsers(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from users");
            while(rs.next()) {
                com.example.demo4.Personal p = new com.example.demo4.Personal();
                p.setId(rs.getInt(1)); ;
                p.setNume(rs.getString(2));
                p.setPrenume(rs.getString(3));
                p.setUsername(rs.getString(4));
                p.setParola(rs.getString(5));
                p.setVarsta(rs.getInt(6)) ;
                p.setEmail(rs.getString(7)) ;
                l.add(p);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    void databaseUserDept(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from userdept");
            while(rs.next()) {
                com.example.demo4.UserDept ud = new com.example.demo4.UserDept();
                ud.setIdAng(rs.getInt(1));
                ud.setIdDept(rs.getInt(2));

                l.add(ud);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }



    void databaseDept(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from dept");
            while(rs.next()) {
                com.example.demo4.Department dept = new Department();
                dept.setId(rs.getInt(1));
                dept.setName(rs.getString(2));

                l.add(dept);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    void vizualizareAngajati(){
        databaseUsers(listaPersonal);
        databaseDept(departments);
        databaseUserDept(listaUserDept);

        for(UserDept ud : listaUserDept){
            int idUser = ud.getIdAng();
            int idDept = ud.getIdDept();
            VizAngajati ang = new VizAngajati();

            for(Personal p : listaPersonal){
                if(p.getId() == idUser){
                    ang.setName(p.getNume()+" "+p.getPrenume());

                }



            }
            for(Department d : departments){
                System.out.println(d.getName());
                if(d.getId() == idDept){
                    ang.setDept(d.getName());

                }
                // break;
            }
            listaVizAngajati.add(ang);
        }
        for(Personal p : listaPersonal){
            int ok = 0;
            for(VizAngajati v : listaVizAngajati)
                if(v.getName().contains(p.getNume()) && v.getName().contains(p.getPrenume()))
                    ok = 1;
            if(ok==0){
                VizAngajati ang = new VizAngajati();
                ang.setName(p.getNume()+" "+p.getPrenume());
                ang.setDept("-");
                listaVizAngajati.add(ang);
            }

        }


        listaVizAngajati.forEach(f->System.out.println(f));

    }


    void trimiteEmail(){
       String alegere = choisePerson.getValue();
       String emailPers="gdfgdfw";
       String nume = "";
        for(Personal p : listaPersonal){
            if(alegere.contains(p.getNume()) && alegere.contains(p.getPrenume())){
                //System.out.println(p.getEmail());
                emailPers=p.getEmail();
                nume = p.getNume();
                break;
            }


        }
        String mesaj = textMessage.getText();

        new SendEmail( nume,mesaj, emailPers);







        System.out.println(mesaj);
        System.out.println(emailPers);
    }
    public void TrimiteButton(ActionEvent event) throws IOException {
        trimiteEmail();
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Informare mail");
        alert.setHeaderText("Mesajul a fost trimis cu succes!");
        alert.setContentText("Apasa pe OK pentru a continua !");
        if(alert.showAndWait().get() == ButtonType.OK){
            Parent root = FXMLLoader.load(getClass().getResource("Mail.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }


    }
    public void BackButton(ActionEvent event) throws IOException {


        Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }



    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        vizualizareAngajati();
        for(VizAngajati d : listaVizAngajati){
            choisePerson.getItems().add(d.getName());
        }
    }
}
