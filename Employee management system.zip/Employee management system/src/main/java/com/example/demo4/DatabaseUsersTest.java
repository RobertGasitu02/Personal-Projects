package com.example.demo4;

import org.testng.annotations.Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class DatabaseUsersTest {
    void databaseUsers(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from userstest");
            while(rs.next()) {
                com.example.demo4.Personal p = new com.example.demo4.Personal();
                p.setId(rs.getInt(1)); ;
                p.setNume(rs.getString(2));
                p.setPrenume(rs.getString(3));
                p.setUsername(rs.getString(4));
                p.setParola(rs.getString(5));
                p.setVarsta(rs.getInt(6)) ;
                p.setEmail(rs.getString(7)) ;
                l.add(p);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }



    @Test
    public void testDatabaseUsers() {
        List<Personal> expectedList = new ArrayList<>();
        Personal p1 = new Personal();
        p1.setId(1);
        p1.setNume("Gasitu");
        p1.setPrenume("Robert");
        p1.setUsername("Robi2002");
        p1.setParola("1234");
        p1.setVarsta(20);
        p1.setEmail("robert.gasitu02@e-uvt.ro");
        expectedList.add(p1);



        List<Personal> actualList = new ArrayList<>();
        databaseUsers(actualList);

        assertEquals(expectedList.size(), actualList.size());
        for (int i = 0; i < expectedList.size(); i++) {
            Personal expected = expectedList.get(i);
            Personal actual = actualList.get(i);
            assertEquals(expected.getId(), actual.getId());
            assertEquals(expected.getNume(), actual.getNume());
            assertEquals(expected.getPrenume(), actual.getPrenume());
            assertEquals(expected.getUsername(), actual.getUsername());
            assertEquals(expected.getParola(), actual.getParola());
            assertEquals(expected.getVarsta(), actual.getVarsta());
            assertEquals(expected.getEmail(), actual.getEmail());
        }
    }
}
