package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class AdminMainController {



    @FXML
    private Button addAngajat;

    @FXML
    private Button addDept;

    @FXML
    private Button gestionare;

    @FXML
    private Button mail;

    @FXML
    private Button cereri;

    @FXML
    private Button exit;


    /**
     * Aceasta metoda este utilizata pentru botonul de addangajat din cadrul form-ului
     * @param event pentru mouseclick
     * @throws IOException pentru tratarea exceptilor
     */
    public void addAngajatButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("RegisterForm.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Aceasta metoda te redirectioneaza catre pagina addDept
     * @param event
     * @throws IOException
     */
    public void addDepartamentButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AddDept.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Acest buton te redirectioneaza catre pagina Gestiune
     * @param event
     * @throws IOException
     */
    public void GestiuneButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Gestionare.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Acest buton te redirectioneaza catre pagina Mail
     * @param event
     * @throws IOException
     */
    public void MailButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Mail.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Acest buton te redirectioneaza catre pagina Cereri
     * @param event
     * @throws IOException
     */
    public void CereriButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminMessage.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }


    /**
     * Aceasta metoda este pentru butonul exit si opreste aplicatia
     * @param event
     * @throws IOException
     */
    public void exitButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

}
