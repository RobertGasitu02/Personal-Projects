package com.example.demo4;

public class Cereri {
    private String nume;
    private String prenume;
    private String titlu;
    private String descriere;
    private String status;

    public Cereri(String nume, String prenume, String titlu, String descriere, String status) {
        this.nume = nume;
        this.prenume = prenume;
        this.titlu = titlu;
        this.descriere = descriere;
        this.status = status;
    }
    public Cereri(){

    }

    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public String getTitlu() {
        return titlu;
    }

    public String getDescriere() {
        return descriere;
    }

    public String getStatus() {
        return status;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setTitlu(String titlu) {
        this.titlu = titlu;
    }

    public void setDescriere(String descriere) {
        this.descriere = descriere;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Cereri{" +
                "nume='" + nume + '\'' +
                ", prenume='" + prenume + '\'' +
                ", titlu='" + titlu + '\'' +
                ", descriere='" + descriere + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
