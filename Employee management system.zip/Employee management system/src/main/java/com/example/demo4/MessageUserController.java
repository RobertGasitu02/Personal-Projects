package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ResourceBundle;

import static com.example.demo4.LoggedUser.logged;

public class MessageUserController implements Initializable {

    @FXML
    private ChoiceBox<String> titlu;
    @FXML
    private TextField descriere;
    @FXML
    private Button trimite;
    @FXML
    private Button back;

    /**
     * Metoda buton redirectionare pagina UserInterface
     * @param event
     * @throws IOException
     */
    public void BackButton(ActionEvent event) throws IOException {


        Parent root = FXMLLoader.load(getClass().getResource("UserInterface.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Aceasta metoda preia informatiile scrise de user in cereri, dupa care le insereaza in tabela cereri
     * @param event
     * @throws IOException
     */
    public void trimiteButton(ActionEvent event) throws IOException {

        String nume,prenume,title,desc,status;
        nume = logged.getNume();
        prenume = logged.getPrenume();
        title = titlu.getValue();
        desc = descriere.getText();
        status = "nerezolvat";

        System.out.println(nume+" "+prenume+" "+title+" "+desc);

        String insertSql = "INSERT INTO cereri (nume, prenume, titlu, descriere,status) VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
             PreparedStatement preparedStatement = connection.prepareStatement(insertSql)) {

            preparedStatement.setString(1, nume);
            preparedStatement.setString(2, prenume);
            preparedStatement.setString(3, title);
            preparedStatement.setString(4, desc);
            preparedStatement.setString(5, status);

            int rowsInserted = preparedStatement.executeUpdate();
            System.out.println(rowsInserted + " row(s) inserted");
        } catch (SQLException e) {
            System.err.println("Error inserting data: " + e.getMessage());
        }
        Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
        alert2.setTitle("Request Information !");
        alert2.setHeaderText(null);
        alert2.setContentText("Mesajul a fost trimis cu succes!");

        alert2.showAndWait();



    }

    /**
     * Folosita pentru a putea initializa choiseBox-ul.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        titlu.getItems().addAll("Concediu", "Probleme", "Schimb", "Altele");
        titlu.setValue("Concediu");
    }
}
