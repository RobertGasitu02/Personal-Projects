package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class AddDeptController {

    @FXML
    private TextField dname;

    @FXML
    private Button create;

    @FXML
    private Button back;


    /**
     * Aceasta metoda face conexiunea cu baza de date pentru crearea unui nou dept.
     * @param deptname retine numele dept. in vederea inserararii in tabel.
     */
    private void connectToDatabase(String deptname) {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            PreparedStatement ps = con.prepareStatement("insert into dept(dname) values(?)");
            ps.setString(1, deptname);
            ps.executeUpdate();
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * Metoda pt butonul de submit
     * @param event pentru mouse click.
     * @throws IOException pentru tratarea exceptilor
     */
    public void createButtonOnAction(ActionEvent event) throws IOException {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Departament creat cu succes!");
        alert.setHeaderText("Departamentul cu numele "+dname.getText()+ " !");
        alert.setContentText("Operatiunea s-a sfarsit, apasa pe OK !");
        if(alert.showAndWait().get() == ButtonType.OK){
            connectToDatabase(dname.getText());


            Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        }

    }

    /**
     * Aceasta metoda este pentru butonul back, te intoarce pe pagina principala.
     * @param event
     * @throws IOException
     */
    public void BackAdminButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }




}
