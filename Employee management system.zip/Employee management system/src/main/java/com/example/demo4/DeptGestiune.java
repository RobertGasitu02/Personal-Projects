package com.example.demo4;

public class DeptGestiune {

        private int id;
        private String name;

        private int nrAngajati;

    public DeptGestiune(int id, String name, int nrAngajati) {
        this.id = id;
        this.name = name;
        this.nrAngajati = nrAngajati;
    }
    public DeptGestiune(){

    }

    @Override
    public String toString() {
        return "DeptGestiune{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", nrAngajati=" + nrAngajati +
                '}';
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNrAngajati(int nrAngajati) {
        this.nrAngajati = nrAngajati;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getNrAngajati() {
        return nrAngajati;
    }
}

