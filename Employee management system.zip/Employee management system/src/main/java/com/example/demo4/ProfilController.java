package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import static com.example.demo4.LoggedUser.logged;

public class ProfilController implements Initializable {

   @FXML
    private Button refresh;
   @FXML
   private Label lNume;
    @FXML
    private Label lPrenume;
    @FXML
    private Label lUsername;
    @FXML
    private Label lDepartament;
    @FXML
    private Label lEmail;

    List<Personal> listaPersonal = new ArrayList<>();
    List<com.example.demo4.UserDept> listaUserDept = new ArrayList<>();
    List<com.example.demo4.VizAngajati> listaVizAngajati = new ArrayList<>();
    List<com.example.demo4.Department> departments = new ArrayList<>();

    /**
     * Metoda utilizata pentru a extrage datele din tabela users.
     * @param l folosit pentru a memora datele din tabela.
     */
    void databaseUsers(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from users");
            while(rs.next()) {
                com.example.demo4.Personal p = new com.example.demo4.Personal();
                p.setId(rs.getInt(1)); ;
                p.setNume(rs.getString(2));
                p.setPrenume(rs.getString(3));
                p.setUsername(rs.getString(4));
                p.setParola(rs.getString(5));
                p.setVarsta(rs.getInt(6)) ;
                p.setEmail(rs.getString(7)) ;
                l.add(p);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * Metoda folosita pentru a lua din tabela userii si dept din care fac parte
     * @param l aici se memorareaza datele extrase
     */
    void databaseUserDept(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from userdept");
            while(rs.next()) {
                com.example.demo4.UserDept ud = new com.example.demo4.UserDept();
                ud.setIdAng(rs.getInt(1));
                ud.setIdDept(rs.getInt(2));

                l.add(ud);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }


    /**
     * Se extrag datele despre departament din baza de date
     * @param l este utilizat pentru a putea memora datele extrase
     */
    void databaseDept(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from dept");
            while(rs.next()) {
                com.example.demo4.Department dept = new Department();
                dept.setId(rs.getInt(1));
                dept.setName(rs.getString(2));

                l.add(dept);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * Metoda este folosita pentru a putea introduce in table view numele angajatului
     * impreuna cu departamentul din care face parte
     */
    void vizualizareAngajati() {
        databaseUsers(listaPersonal);
        databaseDept(departments);
        databaseUserDept(listaUserDept);

        for (UserDept ud : listaUserDept) {
            int idUser = ud.getIdAng();
            int idDept = ud.getIdDept();
            VizAngajati ang = new VizAngajati();

            for (Personal p : listaPersonal) {
                if (p.getId() == idUser) {
                    ang.setName(p.getNume() + " " + p.getPrenume());

                }


            }
            for (Department d : departments) {
                System.out.println(d.getName());
                if (d.getId() == idDept) {
                    ang.setDept(d.getName());

                }
                // break;
            }
            listaVizAngajati.add(ang);
        }
        for (Personal p : listaPersonal) {
            int ok = 0;
            for (VizAngajati v : listaVizAngajati)
                if (v.getName().contains(p.getNume()) && v.getName().contains(p.getPrenume()))
                    ok = 1;
            if (ok == 0) {
                VizAngajati ang = new VizAngajati();
                ang.setName(p.getNume() + " " + p.getPrenume());
                ang.setDept("-");
                listaVizAngajati.add(ang);
            }

        }
    }

    /**
     * Returneaza departamentul din care face parte un angajat
     * @return
     */
    String getDept(){
        vizualizareAngajati();
        String dept="";
        for(VizAngajati va : listaVizAngajati){
            if(va.getName().contains(logged.getNume()) && va.getName().contains(logged.getPrenume()))
                dept = va.getDept();
        }



        return dept;
    }


    /**
     * Metoda utiliza pentru a ne intoarce pe main page
     * @param event
     * @throws IOException
     */
    public void BackButton(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("UserInterface.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    private Button chPass;

    /**
     * Metoda este utilizata pentru a putea schimba parola user-ului
     * se deschide un dialog unde se introduce noua parola
     * apoi se da UPDATE in tabela users in cadrul coloanei parola.
     * @param event
     * @throws IOException
     */
    public void chPassButton(ActionEvent event) throws IOException {
        final String[] password = new String[1];
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Password Input");
        alert.setHeaderText("Introdu noua parola:");

        PasswordField passwordField = new PasswordField();

        GridPane grid = new GridPane();
        grid.add(passwordField, 0, 0);

        alert.getDialogPane().setContent(grid);

        alert.showAndWait().ifPresent(response -> {
             password[0] = passwordField.getText();
            System.out.println("Password entered: " + password[0]);
        });
        System.out.println("Password entered: " + password[0]);

        String name = logged.getNume();
        String newPassword = password[0];

        String updateSql = "UPDATE users SET Parola = ? WHERE Nume = ?";

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
             PreparedStatement preparedStatement = connection.prepareStatement(updateSql)) {

            preparedStatement.setString(1, newPassword);
            preparedStatement.setString(2, name);

            int rowsUpdated = preparedStatement.executeUpdate();
            System.out.println(rowsUpdated + " row(s) updated");
        } catch (SQLException e) {
            System.err.println("Error updating password: " + e.getMessage());
        }
        Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
        alert2.setTitle("Password Update");
        alert2.setHeaderText(null);
        alert2.setContentText("Parola a fost schimbata cu succes!");

        alert2.showAndWait();


    }


    /**
     * Folosit pentru a putea initializa label-uri care contin
     * datele personale ale user-ului deoarece aceasta este modalitatea
     * prin care putem sa le afisam in momentul in care stage-ul este accesat.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        lNume.setText(logged.getNume());
        lPrenume.setText(logged.getPrenume());
        lUsername.setText(logged.getUsername());
        lEmail.setText(logged.getEmail());
        lDepartament.setText(getDept());
    }
}
