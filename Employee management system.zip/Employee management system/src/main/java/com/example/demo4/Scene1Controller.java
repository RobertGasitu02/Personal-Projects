package com.example.demo4;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import java.sql.*;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Scene1Controller {
        private Stage stage;
        private Scene scene;

    @FXML
    private TextField username;

    @FXML
    private PasswordField password;


    List<com.example.demo4.Personal> lista = new ArrayList<>();




    // metoda de preluare a tuturor datelor din tabela de utilizatori ;
    void database(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from users");
            while(rs.next()) {
                com.example.demo4.Personal p = new com.example.demo4.Personal();
                p.setNume(rs.getString(2));
                p.setPrenume(rs.getString(3));
                p.setUsername(rs.getString(4));
                p.setParola(rs.getString(5));
                p.setVarsta(rs.getInt(6)) ;
                p.setEmail(rs.getString(7)) ;
                l.add(p);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    @FXML
    private Button loginButton;
    @FXML
    private Label loginMessage;

    /**
     * Metoda valideaza datele de intrare a utilizatorului
     * Se extrag datele din tabela din bd si se compara
     * cu ceea ce utilizatorul a introdus.
     * @param event
     * @throws IOException
     */
    public void loginButtonOnAction(ActionEvent event) throws IOException {
        database(lista);
        for(com.example.demo4.Personal i : lista){
            if(Objects.equals(i.getUsername(), username.getText()) && Objects.equals(i.getParola(), password.getText())){
                //System.out.println("merge");

                //String uname = i.getUsername();
                //String message = "Acest email este test";
                //String gmail = "robert.gasitu02@e-uvt.ro";
                //new SendEmail( uname,message, gmail);
                LoggedUser.logged = i;
                System.out.println("fdsfsdfs"+i);
                if(Objects.equals(i.getUsername(), "Robi2002")){
                    Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
                    stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                }else{
                    Parent root = FXMLLoader.load(getClass().getResource("UserInterface.fxml"));
                    stage = (Stage)((Node)event.getSource()).getScene().getWindow();
                    scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();

                }



                break;
            }else{
                loginMessage.setText("Username/Parola gresita!");

            }
        }



        /*Parent root = FXMLLoader.load(getClass().getResource("RegisterForm.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();

         */


    }



    @FXML
    private Button cancelButton;


    /**
     * Metoda opreste aplicatia
     * @param event
     */
    public void cancelButtonOnAction(ActionEvent event){

        System.out.println(username.getText());
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();

    }


    /**
     * Metoda ne muta pe pagina RegistrerForm prin intermediul unui buton
     */
    @FXML
    private Button registerButton;
    public void registerButtonOnAction(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("RegisterForm.fxml"));
        stage = (Stage)((Node)event.getSource()).getScene().getWindow();
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }






}
