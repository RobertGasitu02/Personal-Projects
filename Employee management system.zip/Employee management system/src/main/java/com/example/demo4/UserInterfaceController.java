package com.example.demo4;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class UserInterfaceController {
    @FXML
    private Button profil;
    @FXML
    private Button emitecerere;
    @FXML
    private Button exit;

    /**
     * Metoda care ne redirectioneaza catre pagina de login
     * @param event
     * @throws IOException
     */

    public void exitButton(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Scene1.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Metoda care ne redirectioneaza catre pagina Profil
     * Folosita pentru a vizualiza datele personale.
     * @param event
     * @throws IOException
     */
    public void ProfilButton(ActionEvent event) throws IOException {


        Parent root = FXMLLoader.load(getClass().getResource("Profil.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }

    /**
     * Metoda care ne redirectioneaza catre pagina MessageUser
     * @param event
     * @throws IOException
     */
    public void CerereButton(ActionEvent event) throws IOException {


        Parent root = FXMLLoader.load(getClass().getResource("MessageUser.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();


    }
}
