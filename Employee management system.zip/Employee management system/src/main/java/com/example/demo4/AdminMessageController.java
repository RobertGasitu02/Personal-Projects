package com.example.demo4;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.ResourceBundle;

import static com.example.demo4.LoggedUser.logged;

public class AdminMessageController implements Initializable {

    @FXML
    private TableView<Cereri> mesTable;

    @FXML
    private TableColumn<Cereri,String> colNume;

    @FXML
    private TableColumn<Cereri,String> colPrenume;

    @FXML
    private TableColumn<Cereri,String> colTitlu;

    @FXML
    private TableColumn<Cereri,String> colDescriere;

    List<Cereri> listCereri = new ArrayList<>();
    List<Personal> listaPersoane = new ArrayList<>();

    /**
     * Aceasta metoda extrage toate cererile din tabela
     * @param l lista in care se salveaza datele din tabel
     */
    void databaseCereri(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from cereri");
            while(rs.next()) {
                Cereri c = new Cereri();

                c.setNume(rs.getString(1));
                c.setPrenume(rs.getString(2));
                c.setTitlu(rs.getString(3));
                c.setDescriere(rs.getString(4));
                c.setStatus(rs.getString(5));
                if(Objects.equals(c.getStatus(), "nerezolvat"))
                    l.add(c);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }
    @FXML
    private Button backButton;
    @FXML
    private Button adaugaRaspuns;

    /**
     * Aceasta metoda extrage toti useri din tabela users
     * @param l este folosit pentru memorarea datelor.
     */
    void databaseUsers(List l)
    {
        try{
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
            Statement stmt = con.createStatement();
            ResultSet rs;
            rs = stmt.executeQuery("select * from users");
            while(rs.next()) {
                com.example.demo4.Personal p = new com.example.demo4.Personal();
                p.setId(rs.getInt(1)); ;
                p.setNume(rs.getString(2));
                p.setPrenume(rs.getString(3));
                p.setUsername(rs.getString(4));
                p.setParola(rs.getString(5));
                p.setVarsta(rs.getInt(6)) ;
                p.setEmail(rs.getString(7)) ;
                l.add(p);
            }
            l.forEach(f->System.out.println(f));
        }catch(Exception ex){
            ex.printStackTrace();
        }
    }

    /**
     * buton pentru intoarcerea la pagina anterioara
     * @param event
     * @throws IOException
     */
    public void BackButton(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("AdminMain.fxml"));
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Aceasta metoda selectaza din tabel cererea, o deschide, adauga raspuns si il trimite pe mail.
     * @param event
     * @throws IOException
     */
    public void adaugaRaspunsButton(ActionEvent event) throws IOException {
        databaseUsers(listaPersoane);
        String gmail="";
        Cereri selectedAngajat = mesTable.getSelectionModel().getSelectedItem();
        final String[] mesaj = new String[1];
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Adauga raspuns");
        alert.setHeaderText("Descriere: "+selectedAngajat.getDescriere());


        TextField mesajField = new TextField();
        mesajField.setPrefWidth(300);
        mesajField.setPrefHeight(70);
        mesajField.setAlignment(Pos.TOP_LEFT);

        GridPane grid = new GridPane();
        grid.add(mesajField, 0, 0);

        alert.getDialogPane().setContent(grid);

        alert.showAndWait().ifPresent(response -> {
            mesaj[0] = mesajField.getText();
            System.out.println("Raspuns adaugat: " + mesaj[0]);
        });
        System.out.println("Password entered: " + mesaj[0]);



        String updateSql = "UPDATE cereri SET status = ? WHERE nume = ? and prenume = ?";

        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost/proiectjava","root","");
             PreparedStatement preparedStatement = connection.prepareStatement(updateSql)) {

            preparedStatement.setString(1, "rezolvat");
            preparedStatement.setString(2, selectedAngajat.getNume());
            preparedStatement.setString(3, selectedAngajat.getPrenume());

            int rowsUpdated = preparedStatement.executeUpdate();
            System.out.println(rowsUpdated + " row(s) updated");
        } catch (SQLException e) {
            System.err.println("Error updating password: " + e.getMessage());
        }
        Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
        alert2.setTitle("Cerearea a fost solutionata !");
        alert2.setHeaderText(null);
        alert2.setContentText("A fos trimis un mail persoanei cu raspunsul dumneavoastra !");

        if(alert2.showAndWait().get() == ButtonType.OK){
            String uname = selectedAngajat.getNume()+" "+selectedAngajat.getPrenume();
            String message = "Mesajul la cererea dvs. cu titlul " + selectedAngajat.getTitlu() +" este: " + mesaj[0]  ;
            for(Personal p : listaPersoane){
                if(Objects.equals(selectedAngajat.getNume(), p.getNume()) && Objects.equals(selectedAngajat.getPrenume(), p.getPrenume())){
                    gmail = p.getEmail();
                }
            }

            new SendEmail( uname,message, gmail);
        }


    }


    /**
     * Metoda INITIALIZABLE se foloseste pentru a putea insera date in tableview.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        databaseCereri(listCereri);
        ObservableList<Cereri> observableCereriList = FXCollections.observableArrayList(listCereri);
        colNume.setCellValueFactory(new PropertyValueFactory<Cereri,String>("nume"));
        colPrenume.setCellValueFactory(new PropertyValueFactory<Cereri,String>("prenume"));
        colTitlu.setCellValueFactory(new PropertyValueFactory<Cereri,String>("titlu"));
        colDescriere.setCellValueFactory(new PropertyValueFactory<Cereri,String>("descriere"));
        mesTable.setItems(observableCereriList);

    }
}
