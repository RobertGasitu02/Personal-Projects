package com.example.demo4;


public class LoggedUser {
    public static Personal logged;
}
